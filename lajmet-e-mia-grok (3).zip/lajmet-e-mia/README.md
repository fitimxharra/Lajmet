# Lajmet e mia

Faqja që mbledh lajmet nga portalet shqiptare. Rifreskohet vetë çdo 3 minuta dhe lajmi më i ri del i pari.

## Nise

Duhet Node.js 22.

```bash
npm install
npm run dev
```

Hapet te http://localhost:8080

Mos e ngarko dosjen `node_modules`.
